<footer class="main-footer">
    <strong>Footer</a>.</strong>
  </footer>