<div class="image">
          <img src="vistas/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="inicio" class="d-block"><?php echo $_SESSION["nombre"]; ?></a>
        </div>