<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="inicio" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Inicio
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="inventario" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Inventario
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="categorias" class="nav-link">
              <i class="nav-icon fas fa-list-ul"></i>
              <p>
                Categorias
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="tamanos" class="nav-link">
              <i class="nav-icon fas fa-text-height"></i>
              <p>
                Tamaños
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="perfiles" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Perfiles
              </p>
            </a>
          </li>
        </ul>